# Real-time WebSocket Chat Enhancement
# Add this to your requirements.txt: streamlit-webrtc==0.45.0

import streamlit as st
from streamlit_webrtc import webrtc_streamer
import asyncio
import json
from datetime import datetime

class TavernChatWebSocket:
    def __init__(self):
        self.connected_users = set()
        self.message_queue = []
    
    async def handle_message(self, message_data):
        """Handle incoming chat messages"""
        # Save to database
        save_to_database("tavern_messages", message_data)
        
        # Broadcast to all connected users
        for user_session in self.connected_users:
            await self.send_message_to_user(user_session, message_data)
    
    async def send_message_to_user(self, user_session, message_data):
        """Send message to specific user session"""
        try:
            # Update the user's session state
            user_session['tavern_messages'].append(message_data)
            # Trigger UI update
            user_session['chat_updated'] = True
        except Exception as e:
            print(f"Error sending message: {e}")

# Enhanced real-time tavern chat function
def render_realtime_tavern_chat():
    """Render real-time tavern chat with WebSocket support"""
    
    if 'ws_chat_manager' not in st.session_state:
        st.session_state.ws_chat_manager = TavernChatWebSocket()
    
    # Auto-refresh placeholder
    chat_placeholder = st.sidebar.empty()
    
    # Message input
    with st.sidebar.form("tavern_chat_form", clear_on_submit=True):
        new_message = st.text_input("Send a message to the tavern:", 
                                   placeholder="What's the word around town?",
                                   key="tavern_input")
        
        col1, col2 = st.columns([1, 1])
        with col1:
            send_btn = st.form_submit_button("📤 Send", type="primary")
        with col2:
            refresh_btn = st.form_submit_button("🔄 Refresh")
    
    # Handle message sending
    if send_btn and new_message.strip():
        send_tavern_message(new_message.strip())
        st.rerun()
    
    # Handle manual refresh
    if refresh_btn:
        sync_session_with_db()
        st.rerun()
    
    # Display messages with real-time updates
    with chat_placeholder.container():
        st.markdown("**Recent Bar Goss:** 🔄")
        display_tavern_messages()
        
        # Auto-refresh every 2 seconds
        time.sleep(2)
        st.rerun()

# Add this JavaScript for even more real-time updates
def add_realtime_js():
    """Add JavaScript for real-time chat updates"""
    st.markdown("""
    <script>
    // Auto-refresh tavern chat every 3 seconds
    function refreshTavernChat() {
        // Trigger Streamlit rerun
        window.parent.postMessage({
            type: 'streamlit:setComponentValue',
            data: { refresh_chat: true }
        }, '*');
    }
    
    // Set up auto-refresh
    setInterval(refreshTavernChat, 3000);
    
    // Listen for new messages from other users
    window.addEventListener('message', function(event) {
        if (event.data.type === 'tavern_message_update') {
            refreshTavernChat();
        }
    });
    </script>
    """, unsafe_allow_html=True)